# CG CAD Assignment Start Repo

This gives you a starting point for the CAD assignment.    I mainly wanted to help you with some of the GUI code as it is not really the main focus of this assignment,  you are welcome to change or refactor the code as much as you wish. 
 
Enjoy.
Eric

Delete the above replace it with a brief summary of your assignment. 

# Statement of originality 

Except for the list below this assignment has been entirely done by myself.  
__Sixue Hu(u5955909)__
 
Below is the complete list of ideas, help, and source code I obtained for others in completing this assignment:
+ Eric McCreath - starting point CAD code,  used with permission. https://gitlab.cecs.anu.edu.au/u4033585/cgcadassignment2020  (delete this if you don't use Eric's code at all) 
+ I followed the code style and format when drawing new elements such as circles, triangles and arcs.
+ I went online for ideas to approach adding zoom and pan to my program. The websites I visited include https://www.java-forums.org/awt-swing/2927-how-can-we-zoom-map-using-jslider.html and http://web.eecs.utk.edu/~bvanderz/gui/notes/transforms/PanAndZoom.java
