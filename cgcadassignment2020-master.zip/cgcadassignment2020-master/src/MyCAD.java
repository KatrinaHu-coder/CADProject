import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;

// Draw GUI - simple drawing program
// Eric McCreath 2015 GPL
// Edited by Katrina Hu (u5955909)

public class MyCAD extends JComponent implements Runnable, ActionListener {

	public static final String EDITTOOL = "EDITTOOL";

	private static final String EXITCOMMAND = "exitcommand";
	private static final String CLEARCOMMAND = "clearcommand";
	private static final String SAVECOMMAND = "savecommand";
	private static final String OPENCOMMAND = "opencommand";
	JFrame jframe;
	DrawArea drawarea;
	DrawElementFactory drawAreaFactory;
	JSlider scaleSlider;
	Drawing drawing;
	ToolBar drawtool, colortool;
	Graphics g;
	AffineTransform at;   // the current pan and zoom transform
	Point2D XFormedPoint; // storage for a transformed mouse point



	JFileChooser filechooser = new JFileChooser();

	public static void main(String[] args) {
		new MyCAD();
	}

	public MyCAD() {
		SwingUtilities.invokeLater(this);
		JFrame frame = new JFrame();
	}


	public void run() {
		jframe = new JFrame("MyCAD");
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		drawAreaFactory = new BasicDrawElementFactory();
		drawing = new Drawing(drawAreaFactory);

		// set up the menu bar
		JMenuBar bar = new JMenuBar();
		JMenu menu = new JMenu("File");
		bar.add(menu);
		makeMenuItem(menu, "New", CLEARCOMMAND);
		makeMenuItem(menu, "Open", OPENCOMMAND);
		makeMenuItem(menu, "Save", SAVECOMMAND);
		makeMenuItem(menu, "Exit", EXITCOMMAND);

		jframe.setJMenuBar(bar);

		// set up the tool bar at the top of the window that enable actions like clear
		JPanel actionarea = new JPanel();
		actionarea.setLayout(new BoxLayout(actionarea, BoxLayout.X_AXIS));

		// set up the tool bar at the right the enable different drawing functions
		// (edit, line, box, text,...)

		drawtool = new ToolBar(BoxLayout.Y_AXIS);
		drawtool.addbutton("Edit", EDITTOOL);
		drawAreaFactory.addbuttons(drawtool);

		// set up the draw area - this is the JComponent that enable the drawing/viewing
		// of the drawing
		drawarea = new DrawArea(this, drawAreaFactory);


		drawtool.addChangeObserver(new ToolChangeObserver() {
			@Override
			public void update() {
				if (((String) drawtool.getSelectCommand()).equals("EDITTOOL")) {
					jframe.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
				} else {
					jframe.setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
				}
			}
		});


		// code for handling zooming
		JSlider zoomSlider = new JSlider(JSlider.HORIZONTAL, 0, 100, 1);
		zoomSlider.setMajorTickSpacing(25);
		zoomSlider.setMinorTickSpacing(5);
		zoomSlider.setPaintTicks(true);
		zoomSlider.setPaintLabels(true);

//		g = this.getGraphics();
//		Graphics2D g2 = (Graphics2D) g;
//		AffineTransform saveTransform = g2.getTransform();
//		AffineTransform at = new AffineTransform(saveTransform);
////		scaleSlider.setMajorTickSpacing(25);
////		scaleSlider.setMinorTickSpacing(5);
////		scaleSlider.setPaintTicks(true);
////		scaleSlider.setPaintLabels(true);
//		int zoomPercent = scaleSlider.getValue();
//		at.scale((zoomPercent / 100.0), (zoomPercent / 100.0));
//		g2.setTransform(at);
//		int zoomPercent = scaleSlider.getValue();
//		g2.scale(Math.max(0.00001, zoomPercent / 100.0), Math.max(0.00001, zoomPercent / 100.0));
		//scaleSlider.getValue();
//		g2.setTransform(saveTransform);

		colortool = new ToolBar(BoxLayout.Y_AXIS);
		colortool.addbutton("BLACK", Color.black);
		colortool.addbutton("RED", Color.red);
		colortool.addbutton("BLUE", Color.blue);

		JButton jbutton = new JButton("Clear");
		jbutton.setActionCommand(CLEARCOMMAND);
		jbutton.addActionListener(this);
		actionarea.add(jbutton);
		JScrollPane drawpane = new JScrollPane(drawarea, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		drawpane.setPreferredSize(new Dimension(200, 200));
		jframe.getContentPane().add(actionarea, BorderLayout.PAGE_START);
		jframe.getContentPane().add(drawpane, BorderLayout.CENTER);
		jframe.getContentPane().add(drawtool, BorderLayout.LINE_END);
		jframe.getContentPane().add(colortool, BorderLayout.LINE_START);
		jframe.getContentPane().add(zoomSlider, BorderLayout.PAGE_END);
		jframe.setMinimumSize(new Dimension(100, 100));
		jframe.setVisible(true);
		jframe.pack();
	}


	private void makeMenuItem(JMenu menu, String name, String command) {
		JMenuItem menuitem = new JMenuItem(name);
		menu.add(menuitem);
		menuitem.addActionListener(this);
		menuitem.setActionCommand(command);
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		if (ae.getActionCommand().equals(CLEARCOMMAND)) {
			System.out.println("clear");
			drawing.clearDrawing();
			drawarea.repaint();
		} else if (ae.getActionCommand().equals(EXITCOMMAND)) {
			System.exit(0);
		} else if (ae.getActionCommand().equals(SAVECOMMAND)) {
			if (filechooser.showOpenDialog(jframe) == JFileChooser.APPROVE_OPTION) {
				drawing.save(filechooser.getSelectedFile());
			}
		} else if (ae.getActionCommand().equals(OPENCOMMAND)) {
			if (filechooser.showOpenDialog(jframe) == JFileChooser.APPROVE_OPTION) {
				drawing = Drawing.load(filechooser.getSelectedFile(), drawAreaFactory);
				drawarea.repaint();
			}
		}
	}

}