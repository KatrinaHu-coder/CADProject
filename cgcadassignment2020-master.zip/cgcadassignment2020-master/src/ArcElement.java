import java.awt.*;
import java.awt.geom.Point2D;
import java.util.ArrayList;

import static java.lang.Math.abs;

/**
 * Created by Katrina on 31/8/20.
 * Code written by Katrina to draw arc element in the program
 */
public class ArcElement extends DrawElement {
    Point2D start, end;

    public ArcElement(Point2D s, Point2D e) {
        start = s;
        end = e;
    }

    @Override
    public void draw(Graphics2D g) {
        Font font = new Font("Serif", Font.PLAIN, 20);
        g.setFont(font);
        if (end.getX()>start.getX() && end.getY()>start.getY()) {
            g.drawArc((int) start.getX(), (int) start.getY(), (int) abs(end.getX() - start.getX()), (int) abs(start.getY() - end.getY()), 180, 180);
            g.drawRect((int)(((start.getX()+end.getX())/2)-10), (int)(end.getY()+4),30,18);
            g.drawString("Arc", (float) (((start.getX()+end.getX())/2)-10), (float) (end.getY()+20));
            g.drawLine((int)((start.getX()+end.getX())/2), (int)(end.getY()),(int)(((start.getX()+end.getX())/2)-10), (int)(end.getY()+4));
        } else if(end.getX()>start.getX() && end.getY()<start.getY()) {
            g.drawArc((int) start.getX(), (int) end.getY(), (int) abs(start.getX() - end.getX()), (int) abs(start.getY() - end.getY()), 180, -180);
            g.drawRect((int)(((start.getX()+end.getX())/2)-10), (int)(end.getY()-22),30,18);
            g.drawString("Arc", (float) (((start.getX()+end.getX())/2)-10), (float) (end.getY()- 6));
            g.drawLine((int)((start.getX()+end.getX())/2), (int)(end.getY()),(int)(((start.getX()+end.getX())/2)-10), (int)(end.getY()-4));
        } else if(end.getX()<start.getX() && end.getY()>start.getY()){
            g.drawArc((int) end.getX(), (int) start.getY(), (int) abs(start.getX() - end.getX()), (int) abs(start.getY() - end.getY()), 180, 180);
            g.drawRect((int)(((start.getX()+end.getX())/2)-10), (int)(end.getY()+4),30,18);
            g.drawString("Arc", (float) (((start.getX()+end.getX())/2)-10), (float) (end.getY()+20));
            g.drawLine((int)((start.getX()+end.getX())/2), (int)(end.getY()),(int)(((start.getX()+end.getX())/2)-10), (int)(end.getY()+4));

        } else {
            g.drawArc((int) end.getX(), (int) end.getY(), (int) abs(start.getX() - end.getX()), (int) abs(start.getY() - end.getY()), 180, -180);
            g.drawRect((int)(((start.getX()+end.getX())/2)-10), (int)(end.getY()-22),30,18);
            g.drawString("Arc", (float) (((start.getX()+end.getX())/2)-10), (float) (end.getY()- 6));
            g.drawLine((int)((start.getX()+end.getX())/2), (int)(end.getY()),(int)(((start.getX()+end.getX())/2)-10), (int)(end.getY()-4));

        }
        }

    @Override
    public ArrayList<Point2D> controlPoints() {
        ArrayList<Point2D> controlpoints = new ArrayList<Point2D>();
        controlpoints.add(start);
        controlpoints.add(end);
        controlpoints.add(new Point2D.Double(start.getX(), end.getY()));
        controlpoints.add(new Point2D.Double(end.getX(), start.getY()));
        controlpoints.add(PUtil.mid(start, end));
        return controlpoints;
    }

    @Override
    public void moveControlPoint(int control, Point2D pos) {
        if (control == 0)  // top
            start= pos;
        else if (control == 1) // bottomright
            end = pos;

    }

    @Override
    public void storeelement(StoreFacade sf) {
        sf.start("ArcElement");
        sf.addPoint("start", start);
        sf.addPoint("end", end);
    }

    public static DrawElement loadelement(LoadFacade lf) {
        return new ArcElement(lf.getPoint("start"), lf.getPoint("end"));
    }
}

