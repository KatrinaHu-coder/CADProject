/**
 * Created by Katrina on 21/8/20.
 */
import java.awt.*;
import java.awt.geom.Point2D;
import java.util.ArrayList;

/**
 * Created by Katrina on 21/8/20 to draw circles
 * Code edited by Katrina u5955909
 */


public class CircleElement extends DrawElement {

    Point2D topleft, bottomright;

    public CircleElement(Point2D s, Point2D e) {
        topleft = s;
        bottomright = e;
    }

    public void draw(Graphics2D g) {
        Font font = new Font("Serif", Font.PLAIN, 20);
        g.setFont(font);
        if ((topleft.getX() > bottomright.getX())&&(topleft.getY() > bottomright.getY())) {
            g.drawOval((int) bottomright.getX(), (int) bottomright.getY(), (int) (topleft.getX() - bottomright.getX()), (int) (topleft.getY() - bottomright.getY()));
            g.drawRect((int) (bottomright.getX()), (int) (bottomright.getY()-20),50,20);
            g.drawString("Circle", (int) (bottomright.getX()), (int) (bottomright.getY()));
            g.drawLine((int) (bottomright.getX() + (topleft.getX() - bottomright.getX()) / 2) - 20, (int) (bottomright.getY()), (int) bottomright.getX(), (int) bottomright.getY());
        } else if ((topleft.getX() > bottomright.getX()) && (bottomright.getY() > topleft.getY())) {
            g.drawOval((int) (topleft.getX() - (topleft.getX() - bottomright.getX())), (int) topleft.getY(), (int) (topleft.getX() - bottomright.getX()), (int) (bottomright.getY() - topleft.getY()));
            g.drawRect((int) (bottomright.getX()), (int) (bottomright.getY()),50,20);
            g.drawString("Circle", (int) (bottomright.getX()), (int) (bottomright.getY()+20));
            g.drawLine((int) (bottomright.getX() + (topleft.getX() - bottomright.getX()) / 2) - 20, (int) (bottomright.getY()), (int) bottomright.getX(), (int) bottomright.getY());
        } else if ((bottomright.getX() > topleft.getX()) && (topleft.getY() > bottomright.getY())) {
            g.drawOval((int) (bottomright.getX() - (bottomright.getX() - topleft.getX())), (int) bottomright.getY(), (int) (bottomright.getX() - topleft.getX()), (int) (topleft.getY() - bottomright.getY()));
            g.drawRect((int) (bottomright.getX()), (int) (bottomright.getY()),50,20);
            g.drawString("Circle", (int) (bottomright.getX()), (int) (bottomright.getY()+20));
            g.drawLine((int) (bottomright.getX() + (topleft.getX() - bottomright.getX()) / 2), (int) (bottomright.getY()), (int) bottomright.getX(), (int) bottomright.getY());
        } else {
            g.drawOval((int) topleft.getX(), (int) topleft.getY(), (int) (bottomright.getX() - topleft.getX()), (int) (bottomright.getY() - topleft.getY()));
            g.drawRect((int) (bottomright.getX()), (int) (bottomright.getY()-20),50,20);
            g.drawString("Circle", (int) (bottomright.getX()), (int) (bottomright.getY()));
            g.drawLine((int) (bottomright.getX() + (topleft.getX() - bottomright.getX()) / 2), (int) (bottomright.getY()), (int) bottomright.getX(), (int) bottomright.getY());
        }
    }

    public ArrayList<Point2D> controlPoints() {
        ArrayList<Point2D> controlpoints = new ArrayList<Point2D>();
        controlpoints.add(topleft);
        controlpoints.add(bottomright);
        controlpoints.add(PUtil.mid(topleft, bottomright));
        return controlpoints;
    }

    public void moveControlPoint(int control, Point2D pos) {
        if (control == 0)  // topleft
            topleft = pos;
        else if (control == 1) // bottomright
            bottomright = pos;
        else if (control == 2) { // bottomleft
            bottomright = new Point2D.Double(bottomright.getX(), pos.getY());
            topleft = new Point2D.Double(pos.getX(), topleft.getY());
        }
         else if (control == 3) { // topright
            bottomright = new Point2D.Double(pos.getX(), bottomright.getY());
            topleft = new Point2D.Double(topleft.getX(), pos.getY());
        } else if (control == 4) { // center
            Point2D vec = PUtil.sub(pos, PUtil.mid(topleft, bottomright));
            topleft = PUtil.add(topleft, vec);
            bottomright = PUtil.add(bottomright, vec);
        }
    }
    @Override
    public void storeelement(StoreFacade sf) {
        sf.start("CircleElement");
        sf.addPoint("start", topleft);
        sf.addPoint("end", bottomright);

    }

    public static DrawElement loadelement(LoadFacade lf) {
        return new CircleElement(lf.getPoint("start"), lf.getPoint("end"));
    }
}


