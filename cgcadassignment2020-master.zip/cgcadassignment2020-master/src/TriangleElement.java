import java.awt.*;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;

/**
 * Created by Katrina on 28/8/20.
 * Code edited by Katrina u5955909
 */
public class TriangleElement extends DrawElement{

    Point2D top, bottomright;

    public TriangleElement(Point2D s, Point2D e) {
        top = s;
        bottomright = e;
    }

    public void draw(Graphics2D g) {
        g.draw(new Line2D.Double(top, new Point2D.Double(bottomright.getX(), bottomright.getY())));
        g.draw(new Line2D.Double(new Point2D.Double(bottomright.getX(), bottomright.getY()), new Point2D.Double(bottomright.getX()-2*(bottomright.getX()-top.getX()), bottomright.getY())));
        g.draw(new Line2D.Double(new Point2D.Double(bottomright.getX()-2*(bottomright.getX()-top.getX()), bottomright.getY()), top));
        Font font = new Font("Serif", Font.PLAIN, 20);
        g.setFont(font);
        if(bottomright.getY()>top.getY()) {
            g.drawRect((int)(top.getX()+(bottomright.getX()-top.getX())/2)-40, (int)(bottomright.getY()+3),70,22);
            g.drawString("Triangle", (float) (top.getX() + (bottomright.getX() - top.getX()) / 2) - 40, (float) (bottomright.getY() + 20));
            g.drawLine((int) (top.getX() + (bottomright.getX() - top.getX()) / 2) - 40, (int) (bottomright.getY() + 3), (int) bottomright.getX(), (int) bottomright.getY());
        } else {
            g.drawRect((int)(top.getX()+(bottomright.getX()-top.getX())/2)-40, (int)(bottomright.getY()-25),70,22);
            g.drawString("Triangle", (float) (top.getX() + (bottomright.getX() - top.getX()) / 2) - 40, (float) (bottomright.getY()-5));
            g.drawLine((int) (top.getX() + (bottomright.getX() - top.getX()) / 2) - 40, (int) (bottomright.getY()-3), (int) bottomright.getX(), (int) bottomright.getY());

        }
    }

    @Override
    public ArrayList<Point2D> controlPoints() {
        ArrayList<Point2D> controlpoints = new ArrayList<Point2D>();
        controlpoints.add(top);
        controlpoints.add(bottomright);
        controlpoints.add(new Point2D.Double(top.getX(), bottomright.getY()));
        controlpoints.add(new Point2D.Double(bottomright.getX(), top.getY()));
        controlpoints.add(PUtil.mid(top, bottomright));
        return controlpoints;
    }

    @Override
    public void moveControlPoint(int control, Point2D pos) {
        if (control == 0)  // top
            top= pos;
        else if (control == 1) // bottomright
            bottomright = pos;
        else if (control == 2) { // bottomleft
            bottomright = new Point2D.Double(bottomright.getX(), pos.getY());
            top = new Point2D.Double(pos.getX(), top.getY());
        }
//        else if (control == 3) { // topright
//            bottomright = new Point2D.Double(pos.getX(), bottomright.getY());
//            topleft = new Point2D.Double(topleft.getX(), pos.getY());
//        } else if (control == 4) { // center
//            Point2D vec = PUtil.sub(pos, PUtil.mid(topleft, bottomright));
//            topleft = PUtil.add(topleft, vec);
//            bottomright = PUtil.add(bottomright, vec);
//        }

    }

    @Override
    public void storeelement(StoreFacade sf) {
        sf.start("TriangleElement");
        sf.addPoint("top", top);
        sf.addPoint("bottomright", bottomright);

    }

    public static DrawElement loadelement(LoadFacade lf) {
        return new TriangleElement(lf.getPoint("top"), lf.getPoint("bottomright"));
    }
}
