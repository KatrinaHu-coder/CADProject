import java.awt.Color;
import java.awt.Point;

// Edited by Katrina Hu (u5955909)

public class BasicDrawElementFactory implements DrawElementFactory {
	public static final String LINETOOL = "LINETOOL";
	public static final String BOXTOOL = "BOXTOOL";
	public static final String CIRCLETOOL = "CIRCLETOOL";
	public static final String TRIANGLETOOL = "TRIANGLETOOL";
	public static final String ARCTOOL = "ARCTOOL";
	@Override
	public DrawElement createElementFromMousePress(String toolcommand, Color color, Point pos) {
		DrawElement drawelement = null;
		if (toolcommand.equals(LINETOOL)) { 
			drawelement = new LineElement(pos,pos);
		} else if (toolcommand.equals(BOXTOOL)) {
			drawelement = new BoxElement(pos,pos);
		} else if (toolcommand.equals(CIRCLETOOL)) {
			drawelement = new CircleElement(pos,pos);
		} else if (toolcommand.equals(TRIANGLETOOL)) {
			drawelement = new TriangleElement(pos,pos);
		} else if (toolcommand.equals(ARCTOOL)) {
			drawelement = new ArcElement(pos,pos);
		}
		drawelement = new ColorDrawElement(drawelement,
				color);
		return drawelement;
	}

	@Override
	public DrawElement createElementFromLoadFacade(String name, LoadFacade lf) {
		DrawElement element = null;
		if (name.equals("LineElement")) {
			element = LineElement.loadelement(lf);
		} else if (name.equals("BoxElement")) {
			element = BoxElement.loadelement(lf);
		} else if (name.equals("CircleElement")) {
			element = CircleElement.loadelement(lf);
		} else if (name.equals("ArcElement")) {
			element = ArcElement.loadelement(lf);
		} else {
			System.err.println("Unknown Element");
		}
		Integer color = lf.getInteger("color");
		if (color != null) element = new ColorDrawElement(element,new Color(color));
		
		return element;
	}

	@Override
	public void addbuttons(ToolBar drawtool) {
		drawtool.addbutton("Line",LINETOOL);
     	drawtool.addbutton("Box",BOXTOOL);
		drawtool.addbutton("Circle",CIRCLETOOL);
		drawtool.addbutton("Triangle",TRIANGLETOOL);
		drawtool.addbutton("Arc",ARCTOOL);
	}

}
