import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;

// DrawArea - this class deal with the "view" and "control" for the drawing.
// Eric McCreath 2015 GPL
// Code edited by Katrina Hu (u5955909)

public class DrawArea extends JComponent implements MouseMotionListener, MouseListener, ToolChangeObserver {

	private static final long serialVersionUID = 1L;
	static MyCAD drawGUI;
	ElementControlPoint currentControl;
	DrawElementFactory drawAreaFactory;
	private AffineTransform coordTransform = new AffineTransform();
	JSlider scaleSlider;
	static double translateX;
	static double translateY;
	double scale;

	public DrawArea(MyCAD drawGUI, DrawElementFactory drawAreaFactory) {
		translateX = 0;
		translateY = 0;
		scale = 1;
		this.drawGUI = drawGUI;
		this.drawAreaFactory = drawAreaFactory;
		this.scaleSlider = drawGUI.scaleSlider;
		currentControl = null;
		this.setPreferredSize(new Dimension(700, 500));
		this.addMouseMotionListener(this);
		this.addMouseListener(this);
		drawGUI.drawtool.addChangeObserver(this);
	}

//		scaleSlider = new JSlider(JSlider.HORIZONTAL, 1, 100, 1);
//		scaleSlider.setMajorTickSpacing(25);
//		scaleSlider.setMinorTickSpacing(5);
//		scaleSlider.setPaintTicks(true);
//		scaleSlider.setPaintLabels(true);
////		scaleSlider.addChangeListener(ScaleHandler(this));

		protected void paintComponent (Graphics g){
			Graphics2D g2 = (Graphics2D) g;

			g2.setColor(Color.white);
			g2.fillRect(0, 0, getWidth(), getHeight());

			g2.setColor(Color.black);
			drawGUI.drawing.draw(g2);

			g.setColor(Color.black);
			String command = (String) drawGUI.drawtool.getSelectCommand();

			int x = (int) (this.getWidth() - (this.getWidth() * .2)) / 2;
			int y = (int) (this.getHeight() - (this.getHeight() * .2)) / 2;

//            g2.scale(drawGUI.scaleSlider.getValue(),drawGUI.scaleSlider.getValue());

		}

	public Dimension getPreferredSize() {
		return new Dimension(500, 500);
	}

	@Override
	public void mouseDragged(MouseEvent me) {
		if (currentControl != null) {
			currentControl.element.moveControlPoint(currentControl.control, me.getPoint());
		}
		repaint();
	}

	@Override
	public void mouseMoved(MouseEvent arg0) {
	}

	@Override
	public void mouseClicked(MouseEvent me) {

	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	}

	@Override
	public void mousePressed(MouseEvent me) {
		String command = (String) drawGUI.drawtool.getSelectCommand();

		if (command.equals(MyCAD.EDITTOOL)) {
			currentControl = drawGUI.drawing.findControl(me.getPoint());
		} else {
			DrawElement drawelement = drawAreaFactory.createElementFromMousePress(command,
					(Color) drawGUI.colortool.getSelectCommand(), me.getPoint());
			drawGUI.drawing.add(drawelement);
			currentControl = new ElementControlPoint(drawelement, 1);
		}
		repaint();
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		currentControl = null;
	}

	@Override
	public void update() {
		repaint();
	}
}
